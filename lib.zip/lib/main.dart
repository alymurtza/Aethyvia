import 'package:aethyvia/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}
